(function () {
  function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

  function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

  function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["folder-folder-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html":
    /*!*******************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppFolderFolderPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>\n      <span *ngIf=\"generated\" id=\"stopwatch\" [innerText]=\"activeTime\"></span>\n      <span *ngIf=\"!generated\">Wygeneruj Labirynt!</span>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <div id=\"maze_container\">\n    <div id=\"activeCell\" data-rotate=\"0\" data-dir=\"top\"><img src=\"assets/triangle.svg\" /></div>\n    <table id=\"maze\"></table>\n  </div>\n\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/folder/folder-routing.module.ts":
    /*!*************************************************!*\
      !*** ./src/app/folder/folder-routing.module.ts ***!
      \*************************************************/

    /*! exports provided: FolderPageRoutingModule */

    /***/
    function srcAppFolderFolderRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FolderPageRoutingModule", function () {
        return FolderPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _folder_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./folder.page */
      "./src/app/folder/folder.page.ts");

      var routes = [{
        path: '',
        component: _folder_page__WEBPACK_IMPORTED_MODULE_3__["FolderPage"]
      }];

      var FolderPageRoutingModule = function FolderPageRoutingModule() {
        _classCallCheck(this, FolderPageRoutingModule);
      };

      FolderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], FolderPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/folder/folder.module.ts":
    /*!*****************************************!*\
      !*** ./src/app/folder/folder.module.ts ***!
      \*****************************************/

    /*! exports provided: FolderPageModule */

    /***/
    function srcAppFolderFolderModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FolderPageModule", function () {
        return FolderPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _folder_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./folder-routing.module */
      "./src/app/folder/folder-routing.module.ts");
      /* harmony import */


      var _folder_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./folder.page */
      "./src/app/folder/folder.page.ts");

      var FolderPageModule = function FolderPageModule() {
        _classCallCheck(this, FolderPageModule);
      };

      FolderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _folder_routing_module__WEBPACK_IMPORTED_MODULE_5__["FolderPageRoutingModule"]],
        declarations: [_folder_page__WEBPACK_IMPORTED_MODULE_6__["FolderPage"]]
      })], FolderPageModule);
      /***/
    },

    /***/
    "./src/app/folder/folder.page.scss":
    /*!*****************************************!*\
      !*** ./src/app/folder/folder.page.scss ***!
      \*****************************************/

    /*! exports provided: default */

    /***/
    function srcAppFolderFolderPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-menu-button {\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9sZGVyL2ZvbGRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwrQkFBQTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvZm9sZGVyL2ZvbGRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4iXX0= */";
      /***/
    },

    /***/
    "./src/app/folder/folder.page.ts":
    /*!***************************************!*\
      !*** ./src/app/folder/folder.page.ts ***!
      \***************************************/

    /*! exports provided: FolderPage */

    /***/
    function srcAppFolderFolderPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FolderPage", function () {
        return FolderPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs */
      "./node_modules/rxjs/_esm2015/index.js");
      /* harmony import */


      var _services_perfect_maze_perfect_maze_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../services/perfect-maze/perfect-maze.service */
      "./src/app/services/perfect-maze/perfect-maze.service.ts");

      var FolderPage = /*#__PURE__*/function () {
        function FolderPage(alertCtrl, perfectMazeService) {
          _classCallCheck(this, FolderPage);

          this.alertCtrl = alertCtrl;
          this.perfectMazeService = perfectMazeService;
          this.activeTime = '00h : 00m : 00s : 000ms';
          this.config = {
            tableHeight: 500,
            mazeWidth: 10,
            mazeHeight: 10,
            backgroundColorPosition: 'rgb(240, 0, 0)',
            backgroundColorTrace: 'rgb(168, 158, 158)',
            backgroundColorClear: 'rgb(255, 255, 255)',
            backgroundColorRoute: 'rgb(255, 255, 255)',
            backgroundColorExit: 'rgb(0, 200, 0)',
            animationTime: 400,
            validExits: ['right', 'bottom', 'left', 'top'],
            wallColor: 'rgb(0,0,0)',
            startAtRow: 0,
            startAtCol: 0,
            currentCell: 0,
            rowPosition: 0,
            colPosition: 0,
            cursorKeyCodes: [32, 37, 38, 39, 40, 87, 65, 83, 68],
            stopWatchActive: '',
            savedTime: '',
            difference: '',
            interval: false,
            remainingExits: {},
            paused: 0,
            updatedTime: '',
            running: false,
            startTime: null,
            startPosX: 1,
            startPosY: 1
          };
          this.directions = ['left', 'top', 'right', 'bottom'];
          this.generated = false;
        }

        _createClass(FolderPage, [{
          key: "ngAfterViewInit",
          value: function ngAfterViewInit() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.config.rowPosition = 1;
                      this.config.colPosition = 1;
                      this.config.stopWatchActive = false;
                      this.perfectMazeService.getPosition.subscribe(function (data) {
                        if (data.value) {
                          _this.config["startPos".concat(data.direction)] = data.value;
                        }

                        _this.initMaze();
                      });
                      this.perfectMazeService.getGenerate.subscribe(function (data) {
                        _this.generated = true;

                        if (data.value) {
                          _this.config["maze".concat(data.dimension)] = data.value;
                        }

                        _this.initMaze();
                      });
                      this.perfectMazeService.getAnimationTime.subscribe(function (data) {
                        _this.config.animationTime = data;
                      });
                      this.perfectMazeService.getStart.subscribe(function () {
                        _this.start();
                      });
                      Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["fromEvent"])(window, 'resize').subscribe(function () {
                        if (!_this.generated) {
                          return;
                        }

                        _this.setTableSize();
                      });

                    case 8:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "getParameters",
          value: function getParameters() {
            var getParametersString = window.location.search.substr(1);
            var getParameters = getParametersString.split('=');
            return getParameters;
          }
        }, {
          key: "initMaze",
          value: function initMaze() {
            this.config.stopWatchActive = false;
            this.createMaze();
            this.config.rowPosition = this.config.startPosX;
            this.config.colPosition = this.config.startPosY;
            this.config.currentCell = document.getElementById('cell_' + this.config.rowPosition + '_' + this.config.colPosition);
            this.config.currentCell.style.backgroundColor = this.config.backgroundColorPosition;
            this.setTableSize();
            this.activeTime = '00h : 00m : 00s : 000ms';
          }
        }, {
          key: "createMaze",
          value: function createMaze() {
            this.createBlankMaze();
            var startAtRow = 1;
            var startAtCol = 1; // add main route that leads to the goal (with little detours)

            this.addRoute(startAtRow, startAtCol, false); // follow main route and, if empty cells are available, create additional detours

            for (var n = 1; n < this.config.mazeWidth * this.config.mazeHeight - 1; n++) {
              var currentCell = document.getElementById('cell_' + startAtRow + '_' + startAtCol);

              if (currentCell.getAttribute('occupied') == 'true') {
                this.addRoute(startAtRow, startAtCol, true);
              }

              if (startAtCol == this.config.mazeWidth) {
                startAtRow++;
                startAtCol = 1;
              } else {
                startAtCol++;
              }
            }
          }
        }, {
          key: "getNextExits",
          value: function getNextExits(rowIndex, colIndex, createDetour) {
            var nextExits = [];
            var nextPossibleCell = null;

            for (var i = 0; i < this.config.validExits.length; i++) {
              switch (this.config.validExits[i]) {
                case 'right':
                  // if this is a detour call (no route to exit), ignore right movement
                  // // when this would lead to the exit
                  nextPossibleCell = document.getElementById('cell_' + rowIndex + '_' + (colIndex + 1));
                  break;

                case 'left':
                  nextPossibleCell = document.getElementById('cell_' + rowIndex + '_' + (colIndex - 1));
                  break;

                case 'bottom':
                  // if this is a detour call (no route to exit), ignore bottom movement
                  // when this would lead to the exit
                  nextPossibleCell = document.getElementById('cell_' + (rowIndex + 1) + '_' + colIndex);
                  break;

                case 'top':
                  nextPossibleCell = document.getElementById('cell_' + (rowIndex - 1) + '_' + colIndex);
                  break;
              }

              if (nextPossibleCell != null) {
                if (nextPossibleCell.getAttribute('occupied') != 'true') {
                  for (var t = 0; t < this.config.remainingExits[this.config.validExits[i]]; t++) {
                    nextExits.push(this.config.validExits[i]);
                  }
                }
              }
            }

            return nextExits;
          }
        }, {
          key: "addRoute",
          value: function addRoute(startAtRow, startAtCol, createDetour) {
            this.config.remainingExits = JSON.parse(JSON.stringify({
              right: this.config.mazeWidth,
              bottom: this.config.mazeHeight,
              left: 0,
              top: 0
            }));
            var nextExits = [];
            var lastCells = [];
            var rowIndex = startAtRow;
            var colIndex = startAtCol;
            this.config.currentCell = document.getElementById('cell_' + rowIndex + '_' + colIndex);
            var exit;
            var lastExit;
            var exitIndex;
            var loop = 0;
            var loopFuse = 0;
            var maxLoops = 4 * this.config.mazeWidth * this.config.mazeHeight;

            while (loop < this.config.mazeWidth * this.config.mazeHeight - 1) {
              loopFuse++;

              if (loopFuse >= maxLoops) {
                break;
              }

              nextExits = this.getNextExits(rowIndex, colIndex, createDetour);

              if (nextExits.length == 0) {
                if (createDetour) {
                  return false;
                } else {
                  try {
                    lastCells.splice(lastCells.length - 1, 1);
                    rowIndex = lastCells[lastCells.length - 1][0];
                    colIndex = lastCells[lastCells.length - 1][1];
                    this.config.currentCell = document.getElementById('cell_' + rowIndex + '_' + colIndex);
                  } catch (e) {
                    console.warn('something is wrong with lasCells');
                  }

                  continue;
                }
              }

              if (this.config.currentCell == null) {
                continue;
              } // get random exit


              exitIndex = Math.floor(Math.random() * Math.floor(nextExits.length));
              exit = nextExits[exitIndex]; // remove border according to current exit

              this.config.currentCell.style['border-' + exit] = 'none'; // based on random exit, move coordinates to next cell
              // but dont actually select next cell!

              switch (exit) {
                case 'right':
                  colIndex = colIndex + 1;
                  this.config.remainingExits.left++;
                  this.config.remainingExits.right--;
                  break;

                case 'bottom':
                  rowIndex = rowIndex + 1;
                  this.config.remainingExits.top++;
                  this.config.remainingExits.bottom--;
                  break;

                case 'left':
                  colIndex = colIndex - 1;
                  this.config.remainingExits.left--;
                  this.config.remainingExits.right++;
                  break;

                case 'top':
                  rowIndex = rowIndex - 1;
                  this.config.remainingExits.top--;
                  this.config.remainingExits.bottom++;
                  break;
              } // first add new coordinates to route


              lastCells.push([rowIndex, colIndex]); // now jump to next cell

              this.config.currentCell = document.getElementById('cell_' + rowIndex + '_' + colIndex); // and set opposite borders based on exit from the last cell

              switch (exit) {
                case 'right':
                  this.config.currentCell.style['border-left'] = 'none';
                  break;

                case 'bottom':
                  this.config.currentCell.style['border-top'] = 'none';
                  break;

                case 'left':
                  this.config.currentCell.style['border-right'] = 'none';
                  break;

                case 'top':
                  this.config.currentCell.style['border-bottom'] = 'none';
                  break;
              }

              if (rowIndex == this.config.mazeHeight && colIndex == this.config.mazeWidth) {
                break;
              }

              this.config.currentCell.style.backgroundColor = this.config.backgroundColorRoute;
              this.config.currentCell.setAttribute('occupied', 'true');
              lastExit = exit;
              loop++;
            }
          }
        }, {
          key: "createBlankMaze",
          value: function createBlankMaze() {
            var rowIndex;
            var colIndex;
            var table = document.getElementById('maze');
            table.innerHTML = '';
            var tbody = document.createElement('tbody');

            for (rowIndex = 1; rowIndex <= this.config.mazeHeight; rowIndex++) {
              var row = document.createElement('tr');
              row.setAttribute('id', 'row_' + rowIndex);

              for (colIndex = 1; colIndex <= this.config.mazeWidth; colIndex++) {
                var col = document.createElement('td');
                col.style.backgroundColor = 'rgb(255,255,255)';

                if (rowIndex == 1 && colIndex == 1) {
                  col.style.backgroundColor = this.config.backgroundColorRoute;
                  col.setAttribute('occupied', 'true');
                }

                if (rowIndex == this.config.mazeHeight && colIndex == this.config.mazeWidth) {
                  col.style.backgroundColor = this.config.backgroundColorExit;
                }

                col.setAttribute('id', 'cell_' + rowIndex + '_' + colIndex);
                row.appendChild(col);
              }

              tbody.appendChild(row);
            }

            table.appendChild(tbody);
          }
        }, {
          key: "setTableSize",
          value: function setTableSize() {
            var table = document.getElementById('maze');

            if (this.config.mazeWidth == this.config.mazeHeight) {
              var cellWidth = document.getElementById('maze_container').clientWidth / this.config.mazeWidth;
              var cellHeight = document.getElementById('maze_container').clientHeight / this.config.mazeHeight;
              var tableDimension = cellHeight * this.config.mazeHeight - 40;

              if (cellWidth < cellHeight) {
                tableDimension = cellWidth * this.config.mazeWidth - 40;
              }

              table.style.width = tableDimension + 'px';
              table.style.height = tableDimension + 'px';

              for (var i = 0; i < table.querySelectorAll('tr').length; i++) {
                table.querySelectorAll('tr')[i].style.height = "".concat(100 / table.querySelectorAll('tr').length, "%");
              }
            } else {
              table.style.width = document.getElementById('maze_container').clientHeight - 40 - this.config.mazeWidth * 2 + '';
              table.style.height = document.getElementById('maze_container').clientHeight - 40 - this.config.mazeHeight * 2 + '';
            }
          }
        }, {
          key: "stopStopWatch",
          value: function stopStopWatch() {
            clearInterval(this.config.interval);
            this.config.savedTime = this.config.difference;
            this.config.paused = 1;
            this.config.running = 0;
          }
        }, {
          key: "startStopWatch",
          value: function startStopWatch(that) {
            that.config.updatedTime = new Date().getTime();

            if (that.config.savedTime) {
              that.config.difference = that.config.updatedTime - that.config.startTime + that.config.savedTime;
            } else {
              that.config.difference = that.config.updatedTime - that.config.startTime;
            }

            var hours = Math.floor(that.config.difference % (1000 * 60 * 60 * 24) / (1000 * 60 * 60));
            var minutes = Math.floor(that.config.difference % (1000 * 60 * 60) / (1000 * 60));
            var seconds = Math.floor(that.config.difference % (1000 * 60) / 1000);
            var milliseconds = Math.floor(that.config.difference % (1000 * 60) / 100);
            hours = hours < 10 ? '0' + hours : hours;
            minutes = minutes < 10 ? '0' + minutes : minutes;
            seconds = seconds < 10 ? '0' + seconds : seconds;
            milliseconds = milliseconds < 100 ? milliseconds < 10 ? '00' + milliseconds : '0' + milliseconds : milliseconds;
            document.getElementById('stopwatch').innerHTML = hours + 'h : ' + minutes + 'm : ' + seconds + 's : ' + milliseconds + 'ms';
          }
        }, {
          key: "getDegree",
          value: function getDegree(direction) {
            switch (direction) {
              case 'right':
                return 270;

              case 'left':
                return 90;

              case 'top':
                return 0;
            }

            return 180;
          }
        }, {
          key: "goYourSelf",
          value: function goYourSelf() {
            var _this2 = this;

            var _a;

            if (this.config.rowPosition == this.config.mazeHeight && this.config.colPosition == this.config.mazeWidth) {
              this.config.stopWatchActive = false;
              this.stopStopWatch();
              this.showResults();
              return;
            }

            var _loop = function _loop(i) {
              if (_this2.traceCheck(_this2.directions[i], false)) {
                _this2.paintTrace(JSON.parse(JSON.stringify(_this2.directions[i])));

                var findedIndex = _this2.directions.findIndex(function (dir) {
                  return dir == _this2.directions[i];
                });

                findedIndex = findedIndex ? findedIndex - 1 : _this2.directions.length - 1;

                var copyArr = _this2.directions.slice(findedIndex, _this2.directions.length);

                _this2.directions.splice(findedIndex, copyArr.length);

                _this2.directions = [].concat(_toConsumableArray(copyArr), _toConsumableArray(_this2.directions));
                return "break";
              }
            };

            for (var i = 0; i < this.directions.length; i++) {
              var _ret = _loop(i);

              if (_ret === "break") break;
            }

            setTimeout(function () {
              _this2.goYourSelf();
            }, (_a = this.config.animationTime) !== null && _a !== void 0 ? _a : 1000);
          }
        }, {
          key: "start",
          value: function start() {
            if (this.config.stopWatchActive) {
              return;
            }

            this.config.stopWatchActive = true;
            this.config.startTime = new Date().getTime();
            this.config.interval = setInterval(this.startStopWatch, 1, this);
            this.goYourSelf();
            this.perfectMazeService.setConfig(this.config);
          }
        }, {
          key: "traceCheck",
          value: function traceCheck(direction, addResult) {
            var returnValue = false;

            switch (direction) {
              case 'right':
                if (this.config.currentCell.style.borderRight != '') {
                  if (addResult) {
                    this.config.colPosition++;
                  }

                  returnValue = true;
                }

                break;

              case 'left':
                if (this.config.colPosition - 1 === 0) {
                  break;
                }

                if (this.config.currentCell.style.borderLeft != '') {
                  if (addResult) {
                    this.config.colPosition--;
                  }

                  returnValue = true;
                }

                break;

              case 'top':
                if (this.config.rowPosition - 1 === 0) {
                  break;
                }

                if (this.config.currentCell.style.borderTop != '') {
                  if (addResult) {
                    this.config.rowPosition--;
                  }

                  returnValue = true;
                }

                break;

              case 'bottom':
                if (this.config.currentCell.style.borderBottom != '') {
                  if (addResult) {
                    this.config.rowPosition++;
                  }

                  returnValue = true;
                }

                break;
            }

            return returnValue;
          }
        }, {
          key: "paintTrace",
          value: function paintTrace(direction) {
            var lastCell = document.getElementById('cell_' + this.config.rowPosition + '_' + this.config.colPosition);
            var activeCell = document.getElementById('activeCell');
            lastCell.style.backgroundColor = this.config.backgroundColorTrace;
            this.traceCheck(direction, true);
            this.config.currentCell = document.getElementById('cell_' + this.config.rowPosition + '_' + this.config.colPosition);
            this.config.currentCell.style.backgroundColor = this.config.backgroundColorPosition;
            var currentCellDimensions = this.config.currentCell;
            activeCell.style.top = "".concat(document.getElementById('maze').offsetTop + currentCellDimensions.offsetTop, "px");
            activeCell.style.left = "".concat(document.getElementById('maze').offsetLeft + currentCellDimensions.offsetLeft, "px");
            activeCell.style.width = "".concat(currentCellDimensions.offsetWidth, "px");
            activeCell.style.height = "".concat(currentCellDimensions.offsetHeight, "px");
            activeCell.style.transitionDuration = "".concat(this.config.animationTime, "ms");
            var rotateVal = this.getDegree(activeCell.dataset.dir) - this.getDegree(direction);

            if (rotateVal > 0) {
              rotateVal -= 360;
            }

            activeCell.dataset.rotate = String(Number(activeCell.dataset.rotate) + rotateVal);
            activeCell.dataset.dir = direction;
            activeCell.style.transform = "rotate(".concat(activeCell.dataset.rotate, "deg)");
          }
        }, {
          key: "showResults",
          value: function showResults() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var time, alert;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      time = document.getElementById('stopwatch').innerHTML;
                      this.perfectMazeService.setEnd();
                      _context2.next = 4;
                      return this.alertCtrl.create({
                        header: 'Doszliśmy do wyjścia!',
                        message: 'Pokonaliśmy labirynt ' + this.config.mazeWidth + ' x ' + this.config.mazeHeight + ' w czasie ' + time + '.',
                        cssClass: 'customButtons',
                        buttons: ['OK']
                      });

                    case 4:
                      alert = _context2.sent;
                      _context2.next = 7;
                      return alert.present();

                    case 7:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "revealNeighbourWalls",
          value: function revealNeighbourWalls(rowPosition, colPosition) {
            // first row
            if (rowPosition - 1 == 0) {
              // first col
              if (colPosition - 1 == 0) {
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition + 1); // bottom-right cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition); // last col
              } else if (colPosition + 1 > this.config.mazeWidth) {
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1); // bottom-left cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition); // middle col
              } else {
                // left cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1); // bottom-left cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition); // bottom-right cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1); // right cell

                this.removeInvisibleWallClass(rowPosition, colPosition);
              } // last row

            } else if (rowPosition + 1 > this.config.mazeHeight) {
              // first col
              if (colPosition - 1 == 0) {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition); // top-right cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1); // right cell

                this.removeInvisibleWallClass(rowPosition, colPosition + 1); // bottom-right cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition); // last col
              } else if (colPosition + 1 > this.config.mazeWidth) {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition); // top-left cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1); // left cell

                this.removeInvisibleWallClass(rowPosition, colPosition - 1); // middle col
              } else {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition); // top-right cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1); // right cell

                this.removeInvisibleWallClass(rowPosition, colPosition + 1); // top-left cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1); // left cell

                this.removeInvisibleWallClass(rowPosition, colPosition - 1);
              } // middle row

            } else {
              // first col
              if (colPosition - 1 == 0) {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition); // top-right cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1); // right cell

                this.removeInvisibleWallClass(rowPosition, colPosition + 1); // bottom-right cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition); // last col
              } else if (colPosition + 1 > this.config.mazeWidth) {
                // top-left cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1); // top cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition); // left cell

                this.removeInvisibleWallClass(rowPosition, colPosition - 1); // bottom-left cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition); // middle col
              } else {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition); // top-right cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1); // right cell

                this.removeInvisibleWallClass(rowPosition, colPosition + 1); // bottom-right cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition); // top-left cell

                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1); // left cell

                this.removeInvisibleWallClass(rowPosition, colPosition - 1); // bottom-left cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1); // bottom cell

                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
              }
            }
          }
        }, {
          key: "removeInvisibleWallClass",
          value: function removeInvisibleWallClass(rowPosition, colPosition) {
            var neighbourCell = document.getElementById('cell_' + rowPosition + '_' + colPosition);
            neighbourCell.classList.remove('invisibleWall');
          }
        }]);

        return FolderPage;
      }();

      FolderPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
        }, {
          type: _services_perfect_maze_perfect_maze_service__WEBPACK_IMPORTED_MODULE_4__["PerfectMazeService"]
        }];
      };

      FolderPage.propDecorators = {
        mazeContainer: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['mazeContainer']
        }]
      };
      FolderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-folder',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./folder.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./folder.page.scss */
        "./src/app/folder/folder.page.scss"))["default"]]
      })], FolderPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=folder-folder-module-es5.js.map