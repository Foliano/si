(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["folder-folder-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>\n      <span *ngIf=\"generated\" id=\"stopwatch\" [innerText]=\"activeTime\"></span>\n      <span *ngIf=\"!generated\">Wygeneruj Labirynt!</span>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <div id=\"maze_container\">\n    <div id=\"activeCell\" data-rotate=\"0\" data-dir=\"top\"><img src=\"assets/triangle.svg\" /></div>\n    <table id=\"maze\"></table>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/folder/folder-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/folder/folder-routing.module.ts ***!
  \*************************************************/
/*! exports provided: FolderPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FolderPageRoutingModule", function() { return FolderPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _folder_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./folder.page */ "./src/app/folder/folder.page.ts");




const routes = [
    {
        path: '',
        component: _folder_page__WEBPACK_IMPORTED_MODULE_3__["FolderPage"]
    }
];
let FolderPageRoutingModule = class FolderPageRoutingModule {
};
FolderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FolderPageRoutingModule);



/***/ }),

/***/ "./src/app/folder/folder.module.ts":
/*!*****************************************!*\
  !*** ./src/app/folder/folder.module.ts ***!
  \*****************************************/
/*! exports provided: FolderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FolderPageModule", function() { return FolderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _folder_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./folder-routing.module */ "./src/app/folder/folder-routing.module.ts");
/* harmony import */ var _folder_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./folder.page */ "./src/app/folder/folder.page.ts");







let FolderPageModule = class FolderPageModule {
};
FolderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _folder_routing_module__WEBPACK_IMPORTED_MODULE_5__["FolderPageRoutingModule"]
        ],
        declarations: [_folder_page__WEBPACK_IMPORTED_MODULE_6__["FolderPage"]]
    })
], FolderPageModule);



/***/ }),

/***/ "./src/app/folder/folder.page.scss":
/*!*****************************************!*\
  !*** ./src/app/folder/folder.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-menu-button {\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9sZGVyL2ZvbGRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwrQkFBQTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvZm9sZGVyL2ZvbGRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4iXX0= */");

/***/ }),

/***/ "./src/app/folder/folder.page.ts":
/*!***************************************!*\
  !*** ./src/app/folder/folder.page.ts ***!
  \***************************************/
/*! exports provided: FolderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FolderPage", function() { return FolderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _services_perfect_maze_perfect_maze_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/perfect-maze/perfect-maze.service */ "./src/app/services/perfect-maze/perfect-maze.service.ts");





let FolderPage = class FolderPage {
    constructor(alertCtrl, perfectMazeService) {
        this.alertCtrl = alertCtrl;
        this.perfectMazeService = perfectMazeService;
        this.activeTime = '00h : 00m : 00s : 000ms';
        this.config = {
            tableHeight: 500,
            mazeWidth: 10,
            mazeHeight: 10,
            backgroundColorPosition: 'rgb(240, 0, 0)',
            backgroundColorTrace: 'rgb(168, 158, 158)',
            backgroundColorClear: 'rgb(255, 255, 255)',
            backgroundColorRoute: 'rgb(255, 255, 255)',
            backgroundColorExit: 'rgb(0, 200, 0)',
            animationTime: 400,
            validExits: ['right', 'bottom', 'left', 'top'],
            wallColor: 'rgb(0,0,0)',
            startAtRow: 0,
            startAtCol: 0,
            currentCell: 0,
            rowPosition: 0,
            colPosition: 0,
            cursorKeyCodes: [32, 37, 38, 39, 40, 87, 65, 83, 68],
            stopWatchActive: '',
            savedTime: '',
            difference: '',
            interval: false,
            remainingExits: {},
            paused: 0,
            updatedTime: '',
            running: false,
            startTime: null,
            startPosX: 1,
            startPosY: 1,
        };
        this.directions = ['left', 'top', 'right', 'bottom'];
        this.generated = false;
    }
    ngAfterViewInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.config.rowPosition = 1;
            this.config.colPosition = 1;
            this.config.stopWatchActive = false;
            this.perfectMazeService.getPosition.subscribe((data) => {
                if (data.value) {
                    this.config[`startPos${data.direction}`] = data.value;
                }
                this.initMaze();
            });
            this.perfectMazeService.getGenerate.subscribe((data) => {
                this.generated = true;
                if (data.value) {
                    this.config[`maze${data.dimension}`] = data.value;
                }
                this.initMaze();
            });
            this.perfectMazeService.getAnimationTime.subscribe((data) => {
                this.config.animationTime = data;
            });
            this.perfectMazeService.getStart.subscribe(() => {
                this.start();
            });
            Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["fromEvent"])(window, 'resize').subscribe(() => {
                if (!this.generated) {
                    return;
                }
                this.setTableSize();
            });
        });
    }
    getParameters() {
        const getParametersString = window.location.search.substr(1);
        const getParameters = getParametersString.split('=');
        return getParameters;
    }
    initMaze() {
        this.config.stopWatchActive = false;
        this.createMaze();
        this.config.rowPosition = this.config.startPosX;
        this.config.colPosition = this.config.startPosY;
        this.config.currentCell = document.getElementById('cell_' + this.config.rowPosition + '_' + this.config.colPosition);
        this.config.currentCell.style.backgroundColor = this.config.backgroundColorPosition;
        this.setTableSize();
        this.activeTime = '00h : 00m : 00s : 000ms';
    }
    createMaze() {
        this.createBlankMaze();
        let startAtRow = 1;
        let startAtCol = 1;
        // add main route that leads to the goal (with little detours)
        this.addRoute(startAtRow, startAtCol, false);
        // follow main route and, if empty cells are available, create additional detours
        for (let n = 1; n < (this.config.mazeWidth * this.config.mazeHeight) - 1; n++) {
            const currentCell = document.getElementById('cell_' + startAtRow + '_' + startAtCol);
            if (currentCell.getAttribute('occupied') == 'true') {
                this.addRoute(startAtRow, startAtCol, true);
            }
            if (startAtCol == this.config.mazeWidth) {
                startAtRow++;
                startAtCol = 1;
            }
            else {
                startAtCol++;
            }
        }
    }
    getNextExits(rowIndex, colIndex, createDetour) {
        const nextExits = [];
        let nextPossibleCell = null;
        for (let i = 0; i < this.config.validExits.length; i++) {
            switch (this.config.validExits[i]) {
                case 'right':
                    // if this is a detour call (no route to exit), ignore right movement
                    // // when this would lead to the exit
                    nextPossibleCell = document.getElementById('cell_' + rowIndex + '_' + (colIndex + 1));
                    break;
                case 'left':
                    nextPossibleCell = document.getElementById('cell_' + rowIndex + '_' + (colIndex - 1));
                    break;
                case 'bottom':
                    // if this is a detour call (no route to exit), ignore bottom movement
                    // when this would lead to the exit
                    nextPossibleCell = document.getElementById('cell_' + (rowIndex + 1) + '_' + colIndex);
                    break;
                case 'top':
                    nextPossibleCell = document.getElementById('cell_' + (rowIndex - 1) + '_' + colIndex);
                    break;
            }
            if (nextPossibleCell != null) {
                if (nextPossibleCell.getAttribute('occupied') != 'true') {
                    for (let t = 0; t < this.config.remainingExits[this.config.validExits[i]]; t++) {
                        nextExits.push(this.config.validExits[i]);
                    }
                }
            }
        }
        return nextExits;
    }
    addRoute(startAtRow, startAtCol, createDetour) {
        this.config.remainingExits = JSON.parse(JSON.stringify({ right: this.config.mazeWidth, bottom: this.config.mazeHeight, left: 0, top: 0 }));
        let nextExits = [];
        let lastCells = [];
        let rowIndex = startAtRow;
        let colIndex = startAtCol;
        this.config.currentCell = document.getElementById('cell_' + rowIndex + '_' + colIndex);
        let exit;
        let lastExit;
        let exitIndex;
        let loop = 0;
        let loopFuse = 0;
        const maxLoops = 4 * this.config.mazeWidth * this.config.mazeHeight;
        while (loop < ((this.config.mazeWidth * this.config.mazeHeight) - 1)) {
            loopFuse++;
            if (loopFuse >= maxLoops) {
                break;
            }
            nextExits = this.getNextExits(rowIndex, colIndex, createDetour);
            if (nextExits.length == 0) {
                if (createDetour) {
                    return false;
                }
                else {
                    try {
                        lastCells.splice(lastCells.length - 1, 1);
                        rowIndex = lastCells[lastCells.length - 1][0];
                        colIndex = lastCells[lastCells.length - 1][1];
                        this.config.currentCell = document.getElementById('cell_' + rowIndex + '_' + colIndex);
                    }
                    catch (e) {
                        console.warn('something is wrong with lasCells');
                    }
                    continue;
                }
            }
            if (this.config.currentCell == null) {
                continue;
            }
            // get random exit
            exitIndex = Math.floor(Math.random() * Math.floor(nextExits.length));
            exit = nextExits[exitIndex];
            // remove border according to current exit
            this.config.currentCell.style['border-' + exit] = 'none';
            // based on random exit, move coordinates to next cell
            // but dont actually select next cell!
            switch (exit) {
                case 'right':
                    colIndex = colIndex + 1;
                    this.config.remainingExits.left++;
                    this.config.remainingExits.right--;
                    break;
                case 'bottom':
                    rowIndex = rowIndex + 1;
                    this.config.remainingExits.top++;
                    this.config.remainingExits.bottom--;
                    break;
                case 'left':
                    colIndex = colIndex - 1;
                    this.config.remainingExits.left--;
                    this.config.remainingExits.right++;
                    break;
                case 'top':
                    rowIndex = rowIndex - 1;
                    this.config.remainingExits.top--;
                    this.config.remainingExits.bottom++;
                    break;
            }
            // first add new coordinates to route
            lastCells.push([rowIndex, colIndex]);
            // now jump to next cell
            this.config.currentCell = document.getElementById('cell_' + rowIndex + '_' + colIndex);
            // and set opposite borders based on exit from the last cell
            switch (exit) {
                case 'right':
                    this.config.currentCell.style['border-left'] = 'none';
                    break;
                case 'bottom':
                    this.config.currentCell.style['border-top'] = 'none';
                    break;
                case 'left':
                    this.config.currentCell.style['border-right'] = 'none';
                    break;
                case 'top':
                    this.config.currentCell.style['border-bottom'] = 'none';
                    break;
            }
            if (rowIndex == this.config.mazeHeight && colIndex == this.config.mazeWidth) {
                break;
            }
            this.config.currentCell.style.backgroundColor = this.config.backgroundColorRoute;
            this.config.currentCell.setAttribute('occupied', 'true');
            lastExit = exit;
            loop++;
        }
    }
    createBlankMaze() {
        let rowIndex;
        let colIndex;
        const table = document.getElementById('maze');
        table.innerHTML = '';
        const tbody = document.createElement('tbody');
        for (rowIndex = 1; rowIndex <= this.config.mazeHeight; rowIndex++) {
            const row = document.createElement('tr');
            row.setAttribute('id', 'row_' + rowIndex);
            for (colIndex = 1; colIndex <= this.config.mazeWidth; colIndex++) {
                const col = document.createElement('td');
                col.style.backgroundColor = 'rgb(255,255,255)';
                if ((rowIndex == 1 && colIndex == 1)) {
                    col.style.backgroundColor = this.config.backgroundColorRoute;
                    col.setAttribute('occupied', 'true');
                }
                if ((rowIndex == this.config.mazeHeight && colIndex == this.config.mazeWidth)) {
                    col.style.backgroundColor = this.config.backgroundColorExit;
                }
                col.setAttribute('id', 'cell_' + rowIndex + '_' + colIndex);
                row.appendChild(col);
            }
            tbody.appendChild(row);
        }
        table.appendChild(tbody);
    }
    setTableSize() {
        const table = document.getElementById('maze');
        if (this.config.mazeWidth == this.config.mazeHeight) {
            const cellWidth = document.getElementById('maze_container').clientWidth / this.config.mazeWidth;
            const cellHeight = (document.getElementById('maze_container').clientHeight) / this.config.mazeHeight;
            let tableDimension = cellHeight * this.config.mazeHeight - 40;
            if (cellWidth < cellHeight) {
                tableDimension = cellWidth * this.config.mazeWidth - 40;
            }
            table.style.width = tableDimension + 'px';
            table.style.height = tableDimension + 'px';
            for (let i = 0; i < table.querySelectorAll('tr').length; i++) {
                table.querySelectorAll('tr')[i].style.height = `${100 / table.querySelectorAll('tr').length}%`;
            }
        }
        else {
            table.style.width = document.getElementById('maze_container').clientHeight - 40 - (this.config.mazeWidth * 2) + '';
            table.style.height = document.getElementById('maze_container').clientHeight - 40 - (this.config.mazeHeight * 2) + '';
        }
    }
    stopStopWatch() {
        clearInterval(this.config.interval);
        this.config.savedTime = this.config.difference;
        this.config.paused = 1;
        this.config.running = 0;
    }
    startStopWatch(that) {
        that.config.updatedTime = new Date().getTime();
        if (that.config.savedTime) {
            that.config.difference = (that.config.updatedTime - that.config.startTime) + that.config.savedTime;
        }
        else {
            that.config.difference = that.config.updatedTime - that.config.startTime;
        }
        let hours = Math.floor((that.config.difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let minutes = Math.floor((that.config.difference % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((that.config.difference % (1000 * 60)) / 1000);
        let milliseconds = Math.floor((that.config.difference % (1000 * 60)) / 100);
        hours = (hours < 10) ? '0' + hours : hours;
        minutes = (minutes < 10) ? '0' + minutes : minutes;
        seconds = (seconds < 10) ? '0' + seconds : seconds;
        milliseconds = (milliseconds < 100) ? (milliseconds < 10) ? '00' + milliseconds : '0' + milliseconds : milliseconds;
        document.getElementById('stopwatch').innerHTML = hours + 'h : ' + minutes + 'm : ' + seconds + 's : ' + milliseconds + 'ms';
    }
    getDegree(direction) {
        switch (direction) {
            case 'right':
                return 270;
            case 'left':
                return 90;
            case 'top':
                return 0;
        }
        return 180;
    }
    goYourSelf() {
        var _a;
        if (this.config.rowPosition == this.config.mazeHeight && this.config.colPosition == this.config.mazeWidth) {
            this.config.stopWatchActive = false;
            this.stopStopWatch();
            this.showResults();
            return;
        }
        for (let i = 0; i < this.directions.length; i++) {
            if (this.traceCheck(this.directions[i], false)) {
                this.paintTrace(JSON.parse(JSON.stringify((this.directions[i]))));
                let findedIndex = this.directions.findIndex(dir => dir == this.directions[i]);
                findedIndex = findedIndex ? findedIndex - 1 : this.directions.length - 1;
                const copyArr = this.directions.slice(findedIndex, this.directions.length);
                this.directions.splice(findedIndex, copyArr.length);
                this.directions = [...copyArr, ...this.directions];
                break;
            }
        }
        setTimeout(() => {
            this.goYourSelf();
        }, (_a = this.config.animationTime) !== null && _a !== void 0 ? _a : 1000);
    }
    start() {
        if (this.config.stopWatchActive) {
            return;
        }
        this.config.stopWatchActive = true;
        this.config.startTime = new Date().getTime();
        this.config.interval = setInterval(this.startStopWatch, 1, this);
        this.goYourSelf();
        this.perfectMazeService.setConfig(this.config);
    }
    traceCheck(direction, addResult) {
        let returnValue = false;
        switch (direction) {
            case 'right':
                if (this.config.currentCell.style.borderRight != '') {
                    if (addResult) {
                        this.config.colPosition++;
                    }
                    returnValue = true;
                }
                break;
            case 'left':
                if (this.config.colPosition - 1 === 0) {
                    break;
                }
                if (this.config.currentCell.style.borderLeft != '') {
                    if (addResult) {
                        this.config.colPosition--;
                    }
                    returnValue = true;
                }
                break;
            case 'top':
                if (this.config.rowPosition - 1 === 0) {
                    break;
                }
                if (this.config.currentCell.style.borderTop != '') {
                    if (addResult) {
                        this.config.rowPosition--;
                    }
                    returnValue = true;
                }
                break;
            case 'bottom':
                if (this.config.currentCell.style.borderBottom != '') {
                    if (addResult) {
                        this.config.rowPosition++;
                    }
                    returnValue = true;
                }
                break;
        }
        return returnValue;
    }
    paintTrace(direction) {
        const lastCell = document.getElementById('cell_' + this.config.rowPosition + '_' + this.config.colPosition);
        const activeCell = document.getElementById('activeCell');
        lastCell.style.backgroundColor = this.config.backgroundColorTrace;
        this.traceCheck(direction, true);
        this.config.currentCell = document.getElementById('cell_' + this.config.rowPosition + '_' + this.config.colPosition);
        this.config.currentCell.style.backgroundColor = this.config.backgroundColorPosition;
        const currentCellDimensions = this.config.currentCell;
        activeCell.style.top = `${document.getElementById('maze').offsetTop + currentCellDimensions.offsetTop}px`;
        activeCell.style.left = `${document.getElementById('maze').offsetLeft + currentCellDimensions.offsetLeft}px`;
        activeCell.style.width = `${currentCellDimensions.offsetWidth}px`;
        activeCell.style.height = `${currentCellDimensions.offsetHeight}px`;
        activeCell.style.transitionDuration = `${this.config.animationTime}ms`;
        let rotateVal = (this.getDegree(activeCell.dataset.dir) - this.getDegree(direction));
        if (rotateVal > 0) {
            rotateVal -= 360;
        }
        activeCell.dataset.rotate = String(Number(activeCell.dataset.rotate) + (rotateVal));
        activeCell.dataset.dir = direction;
        activeCell.style.transform = `rotate(${activeCell.dataset.rotate}deg)`;
    }
    showResults() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const time = document.getElementById('stopwatch').innerHTML;
            this.perfectMazeService.setEnd();
            const alert = yield this.alertCtrl.create({
                header: 'Doszliśmy do wyjścia!',
                message: 'Pokonaliśmy labirynt ' + this.config.mazeWidth + ' x ' + this.config.mazeHeight + ' w czasie ' + time + '.',
                cssClass: 'customButtons',
                buttons: ['OK'],
            });
            yield alert.present();
        });
    }
    revealNeighbourWalls(rowPosition, colPosition) {
        // first row
        if (rowPosition - 1 == 0) {
            // first col
            if (colPosition - 1 == 0) {
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition + 1);
                // bottom-right cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
                // last col
            }
            else if (colPosition + 1 > this.config.mazeWidth) {
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1);
                // bottom-left cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
                // middle col
            }
            else {
                // left cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1);
                // bottom-left cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
                // bottom-right cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1);
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition);
            }
            // last row
        }
        else if (rowPosition + 1 > this.config.mazeHeight) {
            // first col
            if (colPosition - 1 == 0) {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition);
                // top-right cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1);
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition + 1);
                // bottom-right cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
                // last col
            }
            else if (colPosition + 1 > this.config.mazeWidth) {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition);
                // top-left cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1);
                // left cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1);
                // middle col
            }
            else {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition);
                // top-right cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1);
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition + 1);
                // top-left cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1);
                // left cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1);
            }
            // middle row
        }
        else {
            // first col
            if (colPosition - 1 == 0) {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition);
                // top-right cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1);
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition + 1);
                // bottom-right cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
                // last col
            }
            else if (colPosition + 1 > this.config.mazeWidth) {
                // top-left cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1);
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition);
                // left cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1);
                // bottom-left cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
                // middle col
            }
            else {
                // top cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition);
                // top-right cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition + 1);
                // right cell
                this.removeInvisibleWallClass(rowPosition, colPosition + 1);
                // bottom-right cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition + 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
                // top-left cell
                this.removeInvisibleWallClass(rowPosition - 1, colPosition - 1);
                // left cell
                this.removeInvisibleWallClass(rowPosition, colPosition - 1);
                // bottom-left cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition - 1);
                // bottom cell
                this.removeInvisibleWallClass(rowPosition + 1, colPosition);
            }
        }
    }
    removeInvisibleWallClass(rowPosition, colPosition) {
        const neighbourCell = document.getElementById('cell_' + (rowPosition) + '_' + (colPosition));
        neighbourCell.classList.remove('invisibleWall');
    }
};
FolderPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _services_perfect_maze_perfect_maze_service__WEBPACK_IMPORTED_MODULE_4__["PerfectMazeService"] }
];
FolderPage.propDecorators = {
    mazeContainer: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"], args: ['mazeContainer',] }]
};
FolderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-folder',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./folder.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./folder.page.scss */ "./src/app/folder/folder.page.scss")).default]
    })
], FolderPage);



/***/ })

}]);
//# sourceMappingURL=folder-folder-module-es2015.js.map